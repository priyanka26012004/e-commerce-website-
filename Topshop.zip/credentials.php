<?php
define('WEBSITE_URL', 'http://localhost/topshop');
define('MYSQL_HOSTNAME', 'localhost');
define('MYSQL_USERNAME', 'root');
define('DATABASE_NAME', 'topshop');
define('DATABASE_PASSWORD', '');
define('EMAIL_ADDRESS', 'example@gmail.com');
define('EMAIL_PASSWORD', '********');
?>